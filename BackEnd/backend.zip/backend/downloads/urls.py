from django.urls import path
from .views import DownloadListCreateView, DownloadDetailView, FileDownloadView

urlpatterns = [
    path('', DownloadListCreateView.as_view(), name='download-list-create'),
    path('<int:pk>/', DownloadDetailView.as_view(), name='download-detail-delete'),
    path('<int:pk>/file/', FileDownloadView.as_view(), name='download-file'),
]