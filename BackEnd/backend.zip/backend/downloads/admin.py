# admin.py

from django.contrib import admin
from .models import Download
from store.models import Problem
from accounts.models import User
import boto3
from django.conf import settings
from botocore.exceptions import ClientError
from django.utils.html import format_html
from django.urls import reverse

class DownloadAdmin(admin.ModelAdmin):
    # 리스트 페이지에서 표시할 필드 설정
    list_display = ('id','get_user_email','get_problem_info','get_is_free', 'get_user_username',  'downloaded_at','get_download_file', 'download_url')
    
    # 관련된 객체를 미리 가져와서 쿼리 효율성 향상
    list_select_related = ('user', 'problem')
    
    # 검색 기능 추가
    search_fields = ('user__email','problem__title', 'problem__subject', 'user__username')
    
    # 필터링 기능 추가
    list_filter = ('problem__subject', 'problem__is_free', 'downloaded_at')
    
    # 상세 페이지에서의 필드셋 설정
    fieldsets = (
        ("User", {
            'fields': ('user', 'get_user_email', 'get_user_username')
        }),("Problem", {
            'fields': ('problem', 'get_problem_info', 'downloaded_at',)
        }),("Download", {
            'fields': ('get_download_file','download_url')
        }),
    )
    
    # 읽기 전용 필드 설정
    readonly_fields = ('get_user_email', 'get_user_username', 'get_problem_info', 'downloaded_at', 'get_download_file','download_url')
    
    
    def get_download_file(self,obj) :
        if obj.problem and obj.problem.file:
            return str(obj.problem.file).split('/')[-1]
        return "No file available"
    get_download_file.short_description = 'filename'
    # 사용자 이메일 반환 메서드
    def get_user_email(self, obj):
        return obj.user.email
    get_user_email.short_description = 'User Email'
    
    def get_is_free (self,obj) : 
        
        if obj.problem.is_free:
            return "Yes"
        return "No"
    get_is_free.short_description = 'Is Free'
    
    # 사용자 username 반환 메서드
    def get_user_username(self, obj):
        return obj.user.username
    get_user_username.short_description = 'User Username'
    
    # 문제 제목 반환 메서드 및 링크 추가
    def get_problem_info(self, obj):
        # admin:store_problem_change는 'store' 앱의 'Problem' 모델의 변경 페이지 URL 이름입니다.
        url = reverse("admin:store_problem_change", args=[obj.problem.id])
        return format_html('<a href="{}">({})__{}</a>', url,obj.problem.subject,obj.problem.title)
    get_problem_info.short_description = 'Problem Title'
    
    # 다운로드 URL 반환 메서드 및 링크 추가
    def download_url(self, obj):
        if obj.problem and obj.problem.file:
            # 파일 다운로드 링크 생성
            return format_html('<a href="{}" target="_blank">Download</a>', obj.problem.file.url)
        return "No file available"
    download_url.short_description = 'Download URL'

# Download 모델을 DownloadAdmin과 함께 등록
admin.site.register(Download, DownloadAdmin)
