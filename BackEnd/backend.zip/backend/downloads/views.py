# views.py

from rest_framework import generics, permissions, serializers
from .models import Download
from store.models import Problem
from .serializers import DownloadSerializer
from django.shortcuts import get_object_or_404
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status
from django.http import FileResponse, Http404
import os
from django.utils.timezone import now
import boto3
from django.conf import settings
from botocore.exceptions import ClientError
from rest_framework.pagination import PageNumberPagination
import logging

logger = logging.getLogger(__name__)

class CustomPageNumberPagination(PageNumberPagination):
    page_size = 10  # Default items per page
    page_size_query_param = 'page_size'
    max_page_size = 100

    def get_paginated_response(self, data):
        logger.debug(f"Paginating response: count={self.page.paginator.count}, page={self.page.number}, page_size={self.get_page_size(self.request)}, total_pages={self.page.paginator.num_pages}")
        return Response({
            'count': self.page.paginator.count,
            'page': self.page.number,
            'page_size': self.get_page_size(self.request),
            'total_pages': self.page.paginator.num_pages,
            'results': data
        })

class DownloadListCreateView(generics.ListCreateAPIView):
    serializer_class = DownloadSerializer
    permission_classes = [permissions.IsAuthenticated]
    pagination_class = CustomPageNumberPagination  # Set the pagination class

    def get_queryset(self):
        # Return downloads belonging to the authenticated user
        return Download.objects.filter(user=self.request.user).select_related('problem', 'user').prefetch_related('problem__unit')

    def perform_create(self, serializer):
        # Get the 'problem' from validated data
        problem = serializer.validated_data.get('problem')
        user = self.request.user

        if not problem:
            raise serializers.ValidationError({
                "detail": "Problem information is required."
            })

        # Prevent duplicate downloads for the same problem
        if Download.objects.filter(user=user, problem=problem).exists():
            raise serializers.ValidationError("You have already registered to download this problem set.")

        # Save the download record
        serializer.save(user=user)

    def create(self, request, *args, **kwargs):
        # Override the create method to return the updated list after creation
        serializer = self.get_serializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        self.perform_create(serializer)

        # Fetch the updated list of downloads for the user
        queryset = self.get_queryset()
        page = self.paginate_queryset(queryset)
        if page is not None:
            read_serializer = self.get_serializer(page, many=True)
            return self.get_paginated_response(read_serializer.data)

        # If pagination is not applied, return all data
        read_serializer = self.get_serializer(queryset, many=True)
        return Response(read_serializer.data, status=status.HTTP_201_CREATED)

class DownloadDetailView(generics.RetrieveDestroyAPIView):
    serializer_class = DownloadSerializer
    permission_classes = [permissions.IsAuthenticated]
    pagination_class = CustomPageNumberPagination  # To apply pagination if needed

    def get_queryset(self):
        # Return downloads belonging to the authenticated user
        return Download.objects.filter(user=self.request.user)

    def destroy(self, request, *args, **kwargs):
        # Get the instance to be deleted
        instance = self.get_object()
        self.perform_destroy(instance)

        # Fetch the updated list of downloads for the user
        queryset = self.get_queryset()
        paginator = CustomPageNumberPagination()
        page = paginator.paginate_queryset(queryset, request)
        serializer = self.get_serializer(page, many=True)

        return paginator.get_paginated_response({
            "detail": "Deletion was successful.",
            "data": serializer.data
        })

class FileDownloadView(APIView):
    permission_classes = [permissions.IsAuthenticated]

    def get(self, request, pk, format=None):
        # Retrieve the download instance
        download = get_object_or_404(Download, pk=pk, user=request.user)
        file_path = download.problem.file.path

        # Check if the file exists
        if os.path.exists(file_path):
            return FileResponse(open(file_path, 'rb'), as_attachment=True, filename=os.path.basename(file_path))
        else:
            raise Http404("File not found.")
