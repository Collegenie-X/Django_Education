from django.db import models
from accounts.models import User
from store.models import Problem

# Create your models here.
class Download(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='downloads', help_text="다운로드한 사용자")
    problem = models.ForeignKey(Problem, on_delete=models.CASCADE, related_name='downloads', help_text="다운로드한 문제집")
    downloaded_at = models.DateTimeField(auto_now_add=True, help_text="다운로드 시각")

    class Meta:
        unique_together = ('user', 'problem')
        ordering = ['-downloaded_at']

    def __str__(self):
        return f"{self.user.username} - {self.problem.title}"