# serializers.py

from rest_framework import serializers
from .models import Download
from store.models import Problem, UnitType
from accounts.models import User
import boto3
from django.conf import settings
from botocore.exceptions import ClientError

class UserbyDownloadSerializer(serializers.ModelSerializer):
    email = serializers.EmailField()

    class Meta:
        model = User
        fields = ['email']

class UnitSerializer(serializers.ModelSerializer):
    class Meta:
        model = UnitType
        fields = ['name']  # UnitType 모델의 필드에 따라 조정하세요.

class ProblemByDownloadSerializer(serializers.ModelSerializer):
    grade = serializers.CharField(source='get_grade_display', default='')
    problem_type = serializers.CharField(source='get_problem_type_display', default='')
    type = serializers.CharField(source='get_type_display', default='')
    unit = UnitSerializer(many=True, read_only=True)

    class Meta:
        model = Problem
        fields = ['id','title', 'subject','grade','problem_type', 'type', 'unit', 'is_free' , 'price' ,'discounted_price' ]

class DownloadSerializer(serializers.ModelSerializer):
    user = UserbyDownloadSerializer(read_only=True)
    problem = serializers.PrimaryKeyRelatedField(
        queryset=Problem.objects.all()
    )
    problem_detail = ProblemByDownloadSerializer(source='problem', read_only=True)
    download_url = serializers.SerializerMethodField()

    class Meta:
        model = Download
        fields = ['id', 'user', 'problem', 'problem_detail', 'downloaded_at', 'download_url']
        read_only_fields = ['user', 'downloaded_at', 'download_url', 'problem_detail']


    def get_download_url(self, obj):
        if obj.problem.file:
            return obj.problem.file.url  # S3에 저장된 전체 URL 반환
        return None
