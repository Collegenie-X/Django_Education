export { default } from '@/containers/detail';
