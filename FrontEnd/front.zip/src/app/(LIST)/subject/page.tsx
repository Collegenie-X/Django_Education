export { default } from '@/containers/list/subject';
