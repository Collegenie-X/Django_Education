export { default } from '@/containers/list/free';
