export { default } from '@/containers/list/best';
