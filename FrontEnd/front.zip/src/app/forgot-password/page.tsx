export { default } from '@/containers/forgot-password';
