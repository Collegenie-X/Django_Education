export const KOREA_WON_MONEY = 1320;
